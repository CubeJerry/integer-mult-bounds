# Causal eight-entry source and actual mixed returns

Author finite verification; independent review pending. Both strict suppliers and all five foundations remain open. No new kappa or complete source is claimed. This package validates a physical interface whose complete optimistic fixed bill is already too expensive; it is not the preferred budget route.

## Actual causal preconditioner

The exact parent is standalone Q a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc. Write U=(17,19,30,38,40,47,52,60), G=G_UU, F=G_UH, C=(I+G)^(-1), R=(G-I)C, T=C F. Original Y_U and D_H are genuinely cocharted at0 before any original D departure. Each of the eight already paid rank1 entry packets now acquires R_i*y+T_i*d at0, travels to its original X_i line, and adds that row. All eight first-Y inputs are then snapshotted and replaced by c=C*y-T*d/2 at0. All snapshots retire there.

Actual a=x+R*y+T*d=x+(G-I)c+F*d/2. Thus c+a/2=(x+y)/2 identically, including every independent D term. This addresses the causal contamination obligation directly. The inverse is y=(I+G)c+F*d/2 and x=a-(G-I)c-F*d/2. All old raw routes, all eight global forward packets, and all original dirty inputs remain literal. All400 independent columns and final charts equal the parent under this explicit invertible input substitution.

This preconditioner has6930 instructions,5268 ADD,840 MOVE,410 INIT/CLEAR,2 SCALE,410 lifetimes and peak29. Its MOVE profile is exactly the parent profile. Eight owned snapshot lifetimes are added. Scalar denominators include509 and6617; an exact rational scalar word does not discharge the uniform compiler/precision obligations.

The hosted reverse rows remain rank58 with24 completed endpoints. Actual coupled residual E_U=T*d+2G*C*y has rank7; whole reverse rank65. Every forward residual remains H*a with4569 actual-a coefficients, expanding to14553 original-input coefficients. Hosted cross2G_HU*c and full Gram fitting have not been supplied.

## Actual mixed-return acquisition and consumer

A separate literal word retains the above prefix, executes the independent primal body before the independent hosted-dual body, and verifies that this retiming alone preserves every400-input row. The initial prefix's D reads remain before either body. Therefore all original D_H are still at0 during every primal packet.

For genuine hosted orthonormal frame B=(5,56,65,69,77,96,100,103), define z=G_BH*d, U_B=G_BU, and r=z+2U_B*c. At the actual end of each existing forward packet, the packet at0 adds one z row and the corresponding2U_B current-first-Y row. Its extra current-Y contribution differs from initial c by an explicitly checked linear combination of actual restored Hub a values. The packet really moves0 toHub at rank9. The checker subtracts that known nuisance FROM THE PACKET using genuine Hub a sources, caches the resulting exact r row, and retires the packet atHub. No pure or late Gram observation is assumed.

With W=G_UB, the actual coupled residual is W*r: W*z+2G*c=F*d+2G*(C*y-T*d/2)=T*d+2G*C*y. The Hub consumer subtracts W*r from each actual coupled X output. All eight original coupled reverse endpoints become x_i-y_i, with their original final charts. All original first-Y outputs, original D outputs, and hosted B outputs remain unchanged. Four semantic mutants are rejected, including a missing D read, omitted actual nuisance cancellation, incorrect physical cross factor, and wrong consumer sign.

The8 observations have one pure-D combination because rank(W)=7. Its pure-D row lies outside the current hosted rank58 residual row space, so it gets NO hosted rank credit. The remaining hosted reverse rank is58; all4569 current-a forward coefficients and all14553 expanded coefficients remain. This is not a completion of the global source.

The mixed word has8073 instructions,6387 ADD,848 MOVE,418 INIT/CLEAR,2 SCALE,418 lifetimes, peak30. Exactly8 new rank9 MOVEs are charged. The only newly used chart pair is0 toHub; its exact Clifford/global phase recipe is checked, with a wrong-phase control rejected.

## Complete ordinary and recursive invoices

The generic explicit-pin composition emits both m=3 words on all2280 inputs. Causal precondition only:86721 instructions,7990 MOVE,874 lifetimes,peak43; formal full caller margin10.326451084899253/native rail. Causal mixed-return consumer:89007 instructions,8006 MOVE,890 lifetimes,peak43; formal margin NEGATIVE60.88687721549704/native rail. Every target and paid caller term is retained in those invoices.

Even an unrelated optimistic direct-raw architecture with8entries+8forwardrank9+8newmixedrank9 exceeds the limiting full allowance by0.59380718993 before all further raw/source duties. The package does not claim that this fixed tariff is feasible. Retiming/changed funded payloads or lower packet tariffs would need a new compatible complete word and invoice.

Native all columns, owned erasure, compiler, precision tape, analytic recovery, and strict complex/BIT suppliers remain.
