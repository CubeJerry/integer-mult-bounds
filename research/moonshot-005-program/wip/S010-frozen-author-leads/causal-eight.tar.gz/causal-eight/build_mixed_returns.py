#!/usr/bin/env python3
"""Actual mixed returns after causal8 entry; complete every coupled endpoint."""
import argparse,copy,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def need(q,m):
    if not q:raise ValueError(m)
def null_vector(A):
    R=[list(r) for r in A];piv=[];t=0;n=len(R[0])
    for c in range(n):
        z=next((i for i in range(t,len(R)) if R[i][c]),None)
        if z is None:continue
        R[t],R[z]=R[z],R[t];v=R[t][c];R[t]=[x/v for x in R[t]]
        for i in range(len(R)):
            if i!=t:
                v=R[i][c];R[i]=[x-v*y for x,y in zip(R[i],R[t])]
        piv.append(c);t+=1
    free=next(c for c in range(n) if c not in piv);v=[F(0)]*n;v[free]=F(1)
    for i,c in enumerate(piv):v[c]=-R[i][free]
    return v
def main(a):
    ep=HERE/'source-evidence/extract_rail.py';need(sha(ep.read_bytes())=='7eba542316bfb1a0ae70fee8f2201b7b15abfcfa3cb59f84014f3331608ec372','exact engine');sp=importlib.util.spec_from_file_location('causal_mixed_eight',ep);e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e)
    qb=(HERE/'source-evidence/rail-consumer.json.gz').read_bytes();need(sha(qb)=='a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc','original parent pin');q=json.loads(gzip.decompress(qb));cb=(HERE/'output/rail-causal.json.gz').read_bytes();need(sha(cb)=='5d9a82773439742fb7ee61754dc4fa98c210463e7da6255d51e6557d0ecb3652','actual causal parent');cword=json.loads(gzip.decompress(cb));s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);roles={int(k):v for k,v in q['source_role_map'].items()};host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);U=[17,19,30,38,40,47,52,60];B=[5,56,65,69,77,96,100,103];dual_public={roles[r] for pair in host.values() for r in pair}
    # Colour the ORIGINAL real lifetimes; the new prefix deliberately reads D.
    uf=list(range(400));current={i:i for i in range(400)};nodes=[]
    def find(x):
        while uf[x]!=x:uf[x]=uf[uf[x]];x=uf[x]
        return x
    def union(x,y):
        x,y=find(x),find(y)
        if x!=y:uf[y]=x
    for op in q['program']:
        typ,r=op[:2]
        if typ=='INIT':n=len(uf);uf.append(n);current[r]=n
        node=current[r];nodes.append(node)
        if typ in ['ADD','COPY']:union(node,current[op[2]])
        if typ=='CLEAR':del current[r]
    colors={}
    for i in range(400):colors.setdefault(find(i),set()).add('D' if i in dual_public else 'P')
    need(all(len(v)==1 for v in colors.values()),'original disjoint banks by real lifetime')
    color=lambda n:next(iter(colors.get(find(n),{'P'})))
    primal=[(i,o) for i,o in enumerate(q['program']) if i>=40 and color(nodes[i])=='P'];dual=[(i,o) for i,o in enumerate(q['program']) if color(nodes[i])=='D'];prefix=cword['program'][:cword['causal_eight']['prefix_end']]
    spaces=list(map(e.span,q['frames']));basis={i:{i:F(1)} for i in range(400)};before,bl,oldbill=e.run(cword['program'],q['initial'],400,q['owned_fields'],spaces,basis);retimed=[*prefix]+[o for i,o in primal+dual];rr,rl,rb=e.run(retimed,q['initial'],400,q['owned_fields'],spaces,basis);need(rr==before and rl==bl and rb['moves']==oldbill['moves'] and rb['counts']==oldbill['counts'],'causal prefix then primal-first bank retiming exactly same map')
    pre,pl,_=e.run(prefix,q['initial'],400,q['owned_fields'],spaces,basis);sys.path.insert(0,str(a.repo/'research/moonshot-005-program/results/joint-current-row-codes/review-star'));from engine import root9,rank
    roots={i:root9(s['frames'][s['initial'][i]][0]) for i in s['live']};G=lambda i,j:sum(x*y for x,y in zip(roots[i],roots[j]))/2
    want=[]
    for b in B:
        row={roles[host[h][1]]:G(b,h) for h in H if G(b,h)}
        for u in U:row=e.plus(row,pre[roles[u+112]],2*G(b,u))
        want.append(row)
    W=[[G(u,b) for b in B] for u in U];need(rank(W)==7,'coupled coefficient rank7')
    for u,row in zip(U,W):
        rebuilt={}
        for k,c in enumerate(row):rebuilt=e.plus(rebuilt,want[k],c)
        need(rebuilt==e.plus(before[roles[u]],{roles[u]:F(1),roles[u+112]:F(-1)},-1),'actual coupled residual equals W times the exact mixed initial observations')
    caches={k:400+q['owned_fields']+k for k in range(8)};ops=[];rows=copy.deepcopy(basis);loc=dict(enumerate(q['initial']));events=[]
    def emit(o):
        ops.append(copy.deepcopy(o));typ,r=o[:2]
        if typ=='INIT':need(r not in loc,'trace actual lifetime');loc[r]=o[2];rows[r]={}
        elif typ=='CLEAR':need(loc[r]==o[2],'trace clear chart');del loc[r];del rows[r]
        elif typ=='MOVE':need(loc[r]==o[2],'trace actual move');loc[r]=o[3]
        elif typ in ['ADD','COPY']:need(loc[r]==loc[o[2]]==o[4],'trace real cochart');rows[r]=e.plus(rows[r],rows[o[2]],F(o[3]))
        elif typ=='SCALE':rows[r]={j:F(o[2])*c for j,c in rows[r].items()}
    for o in prefix:emit(o)
    for old,o in primal:
        if o!=['CLEAR',451,3]:emit(o);continue
        k=len(events);b=B[k];start=len(ops);need(all(loc[roles[host[h][1]]]==3 and rows[roles[host[h][1]]]=={roles[host[h][1]]:F(1)} for h in H),'every original D remains available at0 after actual causal prefix')
        for h in H:
            if G(b,h):emit(['ADD',451,roles[host[h][1]],str(G(b,h)),3])
        for u in U:
            if G(b,u):emit(['ADD',451,roles[u+112],str(2*G(b,u)),3])
        nuisance=e.plus(rows[451],want[k],-1);coeff={j:nuisance.get(roles[j],F(0)) for j in s['live']};rebuilt={}
        for j,c in coeff.items():
            need(loc[roles[j]]==127 and rows[roles[j]]==pre[roles[j]],'every nuisance source is actual restored Hub a')
            rebuilt=e.plus(rebuilt,rows[roles[j]],c)
        need(rebuilt==nuisance,'full400-input mixed nuisance is known actual Hub-a combination')
        emit(['MOVE',451,3,127,True])
        for j,c in coeff.items():
            if c:emit(['ADD',451,roles[j],str(-c),127])
        need(rows[451]==want[k],'actual returned packet after nuisance cancellation equals desired r')
        emit(['INIT',caches[k],127]);emit(['ADD',caches[k],451,'1',127]);emit(['CLEAR',451,127]);events.append({'mode':k,'root':b,'original_clear':old,'begin':start,'end':len(ops),'cache':caches[k],'known_Hub_a_nuisance':coeff})
    need(len(events)==8,'all8 funded forward packets became8 genuine upreturns')
    for old,o in dual:emit(o)
    consume_begin=len(ops)
    for u,row in zip(U,W):
        for k,c in enumerate(row):
            if c:emit(['ADD',roles[u],caches[k],str(-c),127])
        need(rows[roles[u]]=={roles[u]:F(1),roles[u+112]:F(-1)},'each actual original coupled reverse endpoint completed')
    null=null_vector(W);pure={}
    for k,c in enumerate(null):pure=e.plus(pure,want[k],c)
    need(pure and set(pure)<={roles[y] for x,y in host.values()},'one authentic pureD mixed-return combination')
    M=[e.plus(before[roles[x]],{roles[x]:F(1),roles[y]:F(-1)},-1) for x,y in host.values()];expr,left=e.coordinate_expression(pure,list(enumerate(M)));credit=not left
    projection=[]
    if credit:
        pivot=next(k for k,c in enumerate(null) if c);field=caches[pivot]
        if null[pivot]!=1:emit(['SCALE',field,str(null[pivot]),127])
        for k,c in enumerate(null):
            if k!=pivot and c:emit(['ADD',field,caches[k],str(c),127])
        need(rows[field]==pure,'actual retained pureD mode assembled atHub')
        dc=min(pure)
        for h,row in zip(H,M):
            c=row.get(dc,F(0))/pure[dc];projection.append(c)
            if c:emit(['ADD',roles[host[h][0]],field,str(-c),127])
    for field in caches.values():emit(['CLEAR',field,127])
    w=copy.deepcopy(cword);w['schema']='moonshot-S010-causal-eight-mixed-return-consumer-v1';w['program']=ops;w['owned_fields']+=8;w['parent_consumer_provenance']=w.pop('consumer');w['mixed_returns']={'parent_causal_sha256':sha(cb),'roots':B,'observations':want,'events':events,'consumer_begin':consume_begin,'coupled_decoder':W,'pureD_mode':pure,'pureD_coefficients':null,'pureD_credit':credit,'hosted_projection_coefficients':projection,'all_original_coupled_reverse_endpoints_completed':True,'full_hosted_cross_constructed':False};after,al,bill=e.run(ops,w['initial'],400,w['owned_fields'],spaces,basis);need(after==rows and al==loc==bl,'complete400-input interpreter replay with all owned fields retired')
    for i in range(400):
        if i in {roles[u] for u in U}:continue
        ix=next((k for k,h in enumerate(H) if roles[host[h][0]]==i),None)
        expected=e.plus(before[i],pure,-projection[ix]) if credit and ix is not None else before[i]
        need(after[i]==expected,'every other original output coefficient retained except explicit pureD hosted projection')
    hrank=rank([[e.plus(after[roles[x]],{roles[x]:F(1),roles[y]:F(-1)},-1).get(k,F(0)) for k in range(400)] for x,y in host.values()]);need(hrank==58-int(credit),'exact remaining hosted reverse rank')
    dm={k:bill['moves'].get(k,0)-oldbill['moves'].get(k,0) for k in bill['moves'].keys()|oldbill['moves'].keys()};need({k:v for k,v in dm.items() if v}=={9:8},'all8 upreturns charged rank9')
    controls=[]
    for kind in ['omit_original_D_read','omit_known_nuisance_cancel','half_instead_of_twice_c','wrong_coupled_consumer_sign']:
        z=copy.deepcopy(w)
        if kind=='omit_original_D_read':lo,hi=events[0]['begin'],events[0]['end'];ix=next(k for k in range(lo,hi) if z['program'][k][0]=='ADD' and z['program'][k][1]==451 and z['program'][k][2] in {roles[y] for x,y in host.values()})
        elif kind=='omit_known_nuisance_cancel':lo,hi=events[0]['begin'],events[0]['end'];ix=next(k for k in range(lo,hi) if z['program'][k][0]=='ADD' and z['program'][k][1]==451 and z['program'][k][4]==127)
        elif kind=='half_instead_of_twice_c':lo,hi=events[0]['begin'],events[0]['end'];ix=next(k for k in range(lo,hi) if z['program'][k][0]=='ADD' and z['program'][k][1]==451 and z['program'][k][2] in {roles[u+112] for u in U});z['program'][ix][3]=str(F(z['program'][ix][3])/4)
        else:ix=consume_begin;z['program'][ix][3]=str(-F(z['program'][ix][3]))
        if kind in ['omit_original_D_read','omit_known_nuisance_cancel']:z['program'][ix][3]='0'
        ar,aa,_=e.run(z['program'],q['initial'],400,w['owned_fields'],spaces,basis);need(ar!=after,'mixed-return mutant rejected '+kind);controls.append({'name':kind,'event':ix,'rejected':True})
    w['scope']='Actual eight mixed returns complete all coupled8 original endpoints using the8 paid causal entry calls. Hosted reverse rank'+str(hrank)+' and4569 current-a forward coefficients remain; no complete supplier.';payload=(json.dumps(e.clean(w),sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(payload,mtime=0);a.output.mkdir(parents=True,exist_ok=True);(a.output/'rail-causal-mixed.json.gz').write_bytes(blob)
    result={'status':'PASS_ACTUAL_CAUSAL_EIGHT_MIXED_RETURNS','parent_causal_sha256':sha(cb),'parent_original_sha256':sha(qb),'word_sha256':sha(blob),'payload_sha256':sha(payload),'input_directions':400,'bill':bill,'ordinary_increment':{k:bill['counts'].get(k,0)-oldbill['counts'].get(k,0) for k in bill['counts'].keys()|oldbill['counts'].keys()},'paid_move_increment':{9:8},'all_original_coupled_reverse_ports_complete':U,'coupled_residual_rank_before':7,'coupled_residual_rank_after':0,'hosted_residual_rank_before':58,'hosted_residual_rank_after':hrank,'pureD_mode_credit':credit,'pureD_mode':pure,'pureD_mode_outside_hosted_residual_remainder':left,'observations':want,'events':events,'all_original_firstY_rows_unchanged':True,'all_original_hosted_D_rows_unchanged':True,'forward_residual_current_a':4569,'forward_residual_original_inputs':14553,'negative_controls':controls,'scope':w['scope']+' Both strict suppliers and all five foundations remain.'};(a.output/'RESULT.json').write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print(json.dumps(e.clean({k:result[k] for k in ['status','word_sha256','bill','ordinary_increment','hosted_residual_rank_after','pureD_mode_credit']}),indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
