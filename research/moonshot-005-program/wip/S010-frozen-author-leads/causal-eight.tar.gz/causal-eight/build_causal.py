#!/usr/bin/env python3
"""Causal coupled8 precondition, using the already paid eight rank1 entries."""
import argparse,copy,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def need(q,m):
    if not q:raise ValueError(m)
def inverse(A):
    n=len(A);B=[list(r)+[F(i==j) for j in range(n)] for i,r in enumerate(A)]
    for k in range(n):
        z=next(i for i in range(k,n) if B[i][k]);B[k],B[z]=B[z],B[k];c=B[k][k];B[k]=[x/c for x in B[k]]
        for i in range(n):
            if i!=k:
                c=B[i][k];B[i]=[x-c*y for x,y in zip(B[i],B[k])]
    return [r[n:] for r in B]
def mm(A,B):return [[sum(x*B[k][j] for k,x in enumerate(row)) for j in range(len(B[0]))] for row in A]
def main(a):
    ep=HERE/'source-evidence/extract_rail.py';need(sha(ep.read_bytes())=='7eba542316bfb1a0ae70fee8f2201b7b15abfcfa3cb59f84014f3331608ec372','exact engine');sp=importlib.util.spec_from_file_location('causal_eight',ep);e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e)
    qb=(HERE/'source-evidence/rail-consumer.json.gz').read_bytes();need(sha(qb)=='a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc','parent pin');q=json.loads(gzip.decompress(qb));s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);roles={int(k):v for k,v in q['source_role_map'].items()}
    host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);U=[17,19,30,38,40,47,52,60]
    sys.path.insert(0,str(a.repo/'research/moonshot-005-program/results/joint-current-row-codes/review-star'));from engine import root9,rank
    roots={i:root9(s['frames'][s['initial'][i]][0]) for i in s['live']};G=lambda i,j:sum(x*y for x,y in zip(roots[i],roots[j]))/2;Gu=[[G(i,j) for j in U] for i in U];I=[[F(i==j) for j in range(8)] for i in range(8)];C=inverse([[I[i][j]+Gu[i][j] for j in range(8)] for i in range(8)]);R=mm([[Gu[i][j]-I[i][j] for j in range(8)] for i in range(8)],C);T=mm(C,[[G(i,j) for j in H] for i in U])
    oldentry=[];prefix=[]
    # All original Y_U and D_H are at0 now. These are original rows, not
    # presumed late current-row or Gram observations.
    for i,j in enumerate(U):
        L=s['initial'][j];oldentry.extend([['INIT',400,3],['ADD',400,roles[j+112],'1',3],['MOVE',400,3,L,True],['ADD',roles[j],400,'-1',L],['CLEAR',400,L]])
        prefix.append(['INIT',400,3]);prefix.extend([['ADD',400,roles[h+112],str(c),3] for h,c in zip(U,R[i]) if c]);prefix.extend([['ADD',400,roles[host[h][1]],str(c),3] for h,c in zip(H,T[i]) if c]);prefix.extend([['MOVE',400,3,L,True],['ADD',roles[j],400,'1',L],['CLEAR',400,L]])
    need(q['program'][:40]==oldentry,'literal parent eight entries')
    for k,j in enumerate(U):prefix.extend([['INIT',400+k,3],['ADD',400+k,roles[j+112],'1',3]])
    for i,j in enumerate(U):
        prefix.append(['ADD',roles[j+112],400+i,'-1',3]);prefix.extend([['ADD',roles[j+112],400+k,str(c),3] for k,c in enumerate(C[i]) if c]);prefix.extend([['ADD',roles[j+112],roles[host[h][1]],str(-c/2),3] for h,c in zip(H,T[i]) if c])
    prefix.extend([['CLEAR',400+k,3] for k in range(8)])
    w=copy.deepcopy(q);w['program']=prefix+q['program'][40:];w['schema']='moonshot-S010-causal-coupled-eight-preconditioner-v1';w['parent_rail_sha256']=sha(qb);shift=len(prefix)-40
    for field in ['begin','end']:w['consumer'][field]+=shift
    for t in w['consumer']['lifetimes']:
        for field in ['begin','end']:t[field]+=shift
    w['causal_eight']={'U':U,'H':H,'C':C,'R':R,'T':T,'prefix_end':len(prefix),'physical_c':'C*y-T*d/2','actual_a':'x+R*y+T*d','information_inverse':'y=(I+G)c+G_UH*d/2; x=a-(G-I)c-G_UH*d/2','entry_transport_calls':8,'all_coupled_Y_stay_at0_for_forward_packets':True,'cross_coupled_T_actually_acquired':True,'hosted_cross_2G_HU_c_constructed':False,'mixed_reverse_observations_constructed':False}
    spaces=list(map(e.span,q['frames']));basis={i:{i:F(1)} for i in range(400)};before,bl,oldbill=e.run(q['program'],q['initial'],400,q['owned_fields'],spaces,basis);after,al,bill=e.run(w['program'],w['initial'],400,w['owned_fields'],spaces,basis);pre,pl,_=e.run(prefix,q['initial'],400,q['owned_fields'],spaces,basis)
    sub=copy.deepcopy(basis)
    for i,j in enumerate(U):
        c={roles[h+112]:v for h,v in zip(U,C[i]) if v}
        for h,v in zip(H,T[i]):c=e.plus(c,{roles[host[h][1]]:F(1)},-v/2)
        av={roles[j]:F(1)}
        for h,v in zip(U,R[i]):av=e.plus(av,{roles[h+112]:F(1)},v)
        for h,v in zip(H,T[i]):av=e.plus(av,{roles[host[h][1]]:F(1)},v)
        need(pre[roles[j]]==av and pre[roles[j+112]]==c,'actual full original-input a and physical c')
        need(e.plus(c,av,F(1,2))=={roles[j]:F(1,2),roles[j+112]:F(1,2)},'no D contamination in physical half-forward self term')
        sub[roles[j+112]]=c;sub[roles[j]]=e.plus(av,c)
    expected,el,_=e.run(q['program'],q['initial'],400,q['owned_fields'],spaces,sub);need(after==expected and al==el==bl,'all400 input columns and original endpoints equal exact invertible parent precomposition')
    for x,y in host.values():need(after[roles[x]]==before[roles[x]] and after[roles[y]]==before[roles[y]],'all hosted B/D rows unchanged')
    ideal=lambda i:{roles[i]:F(1,2) if i in U else F(1),roles[i+112]:F(1,2) if i in U else F(1)};errs={};oldH={}
    for i in s['live']:
        old=e.plus(before[roles[i+112]],ideal(i),-1);errs[i]=e.plus(after[roles[i+112]],ideal(i),-1);oldH[i]={j:old.get(roles[j],F(0)) for j in s['live'] if old.get(roles[j],F(0))};rebuilt={}
        for j,c in oldH[i].items():rebuilt=e.plus(rebuilt,pre[roles[j]],c)
        need(rebuilt==errs[i],'all forward residual exactly unchanged H applied to actual a')
    need(sum(map(len,oldH.values()))==4569,'4569 unchanged current-a coefficients')
    rev=[e.plus(after[roles[x]],{roles[x]:F(1),roles[y]:F(-1)},-1) for x,y in host.values()];crev=[e.plus(after[roles[j]],{roles[j]:F(1),roles[j+112]:F(-1)},-1) for j in U];ranks=[rank([[r.get(k,F(0)) for k in range(400)] for r in rows]) for rows in [rev,crev,rev+crev]];need(ranks==[58,7,65],'actual residual ranks58/7/65')
    need(bill['moves']==oldbill['moves'] and bill['peak']==29 and bill['lifetimes']==oldbill['lifetimes']+8,'no new transport and eight genuine snapshot lifetimes')
    controls=[]
    for kind in ['omit_initial_D_compensation','omit_D_entry_payload','wrong_physical_half']:
        z=copy.deepcopy(w)
        if kind=='omit_initial_D_compensation':ix=next(k for k,o in enumerate(prefix) if o[0]=='ADD' and o[1]==roles[129] and o[2] in {roles[y] for x,y in host.values()})
        elif kind=='omit_D_entry_payload':ix=next(k for k,o in enumerate(prefix) if o[0]=='ADD' and o[1]==400 and o[2] in {roles[y] for x,y in host.values()})
        else:ix=next(k for k,o in enumerate(prefix) if o[0]=='ADD' and o[1]==roles[129] and o[2]>=400)
        z['program'][ix][3]='0';ar,aa,_=e.run(z['program'],q['initial'],400,q['owned_fields'],spaces,basis);need(ar!=after,'causal semantic mutant rejected '+kind);controls.append({'name':kind,'event':ix,'rejected':True})
    den=sorted({F(o[3] if o[0] in ['ADD','COPY'] else o[2]).denominator for o in w['program'] if o[0] in ['ADD','COPY','SCALE']});w['scope']='Actual causal eight-entry partial400-input preconditioner; coupled T acquired and D-forward self contamination cancelled. Hosted cross, full forward fitting and mixed returns remain absent.'
    payload=(json.dumps(e.clean(w),sort_keys=True,separators=(',',':'))+'\n').encode();blob=gzip.compress(payload,mtime=0);a.output.mkdir(parents=True,exist_ok=True);(a.output/'rail-causal.json.gz').write_bytes(blob)
    result={'status':'PASS_ACTUAL_CAUSAL_EIGHT_ENTRY','parent_rail_sha256':sha(qb),'native_sha256':e.SOURCE_PIN,'word_sha256':sha(blob),'payload_sha256':sha(payload),'bill':bill,'ordinary_increment':{k:bill['counts'].get(k,0)-oldbill['counts'].get(k,0) for k in bill['counts'].keys()|oldbill['counts'].keys()},'paid_move_increment':{},'input_directions':400,'all_raw_routes_and_global_packets_literal':True,'C':C,'R':R,'T':T,'coupled_T_rank':rank(T),'coupled_T_actually_acquired':True,'forward_D_self_contamination_exactly_cancelled':True,'hosted_cross_constructed':False,'mixed_returns_constructed':False,'forward_residual_current_a':4569,'forward_residual_original_inputs':sum(map(len,errs.values())),'hosted_reverse_rank':58,'coupled_reverse_rank':7,'joint_reverse_rank':65,'scalar_denominators':den,'negative_controls':controls,'scope':w['scope']+' Both strict suppliers and all five foundations remain.'}
    (a.output/'RESULT.json').write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print(json.dumps(e.clean({k:result[k] for k in ['status','word_sha256','bill','ordinary_increment','coupled_T_rank','forward_residual_original_inputs','scalar_denominators']}),indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
