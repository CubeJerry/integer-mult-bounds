#!/usr/bin/env python3
"""Allow every first-X output an arbitrary already-observable pureD mode."""
import argparse,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def kernel(A):
    R=[list(r) for r in A];piv=[];t=0;n=len(R[0])
    for c in range(n):
        z=next((i for i in range(t,len(R)) if R[i][c]),None)
        if z is None:continue
        R[t],R[z]=R[z],R[t];v=R[t][c];R[t]=[x/v for x in R[t]]
        for i in range(len(R)):
            if i!=t:
                v=R[i][c];R[i]=[x-v*y for x,y in zip(R[i],R[t])]
        piv.append(c);t+=1
    ans=[]
    for free in range(n):
        if free in piv:continue
        v=[F(0)]*n;v[free]=F(1)
        for i,c in enumerate(piv):v[c]=-R[i][free]
        ans.append(v)
    return ans
def main(a):
    sp=importlib.util.spec_from_file_location('quotient_cache_engine',HERE/'extract_rail.py');e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e);s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);q=json.loads(gzip.decompress((HERE.parent/'two-lane/source-evidence/rail-consumer.json.gz').read_bytes()));roles={int(k):v for k,v in q['source_role_map'].items()};host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);X=s['live'];S=[17,19,38,40];B=[5,56,65,69,77,96,100,103]
    sys.path.insert(0,str(a.repo/'research/moonshot-005-program/results/joint-current-row-codes/review-star'));from engine import root9,rank
    roots={i:root9(s['frames'][s['initial'][i]][0]) for i in X};G=lambda i,j:sum(x*y for x,y in zip(roots[i],roots[j]))/2;W=[[G(i,b) for b in B] for i in S];Z=kernel(W);assert len(Z)==5;K=[[sum(z[k]*G(b,h) for k,b in enumerate(B)) for h in H] for z in Z];assert rank(K)==5
    raw=a.source.read_bytes();d=json.loads(raw);contacts={h:[] for h in H}
    for col in d['injection_manifest']:
        v={int(i):F(c) for i,c in col['injection']['future_X_effect'].items()};row={int(i):F(c) for i,c in col['donor_history']['row'].items()};assert len(row)==1;field=next(iter(row));h=next(h for h in H if roles[host[h][1]]==field);contacts[h].append(v)
    equations=[];echelon={};failure=None
    for hi,h in enumerate(H):
        basis={}
        for v in contacts[h]:
            row=dict(v)
            while row:
                p=min(row);c=row[p]
                if p not in basis:basis[p]={i:v/c for i,v in row.items()};break
                row=e.plus(row,basis[p],-c)
        def reduce(v):
            row=dict(v)
            for p in sorted(basis):
                if row.get(p):row=e.plus(row,basis[p],-row[p])
            return row
        target=reduce({i:G(i,h)/2 for i in S if G(i,h)});units={i:reduce({i:F(1)}) for i in X};indices=set(target)
        for v in units.values():indices.update(v)
        for j in sorted(indices):
            coeff={}
            for xi,i in enumerate(X):
                if not units[i].get(j):continue
                for k in range(5):
                    if K[k][hi]:coeff[5*xi+k]=units[i][j]*K[k][hi]
            rhs=-target.get(j,F(0));eqid=len(equations);equations.append({'D_port':h,'quotient_X':j,'coeff':coeff,'rhs':rhs});row=dict(coeff);b=rhs;proof={eqid:F(1)}
            while row:
                p=min(row);c=row[p]
                if p not in echelon:
                    echelon[p]=({i:v/c for i,v in row.items()},b/c,{i:v/c for i,v in proof.items()});break
                v,bb,pp=echelon[p];row=e.plus(row,v,-c);b-=c*bb;proof=e.plus(proof,pp,-c)
            if not row and b:
                failure={'event':eqid,'rhs':b,'combination':proof};break
        if failure:break
    status='UNSAT_EXACT_OBSERVABLE_QUOTIENT' if failure else 'SAT_EXACT_OBSERVABLE_QUOTIENT';result={'status':status,'source_sha256':hashlib.sha256(raw).hexdigest(),'variables':5*len(X),'equations_processed':len(equations),'rank':len(echelon),'pureD_mode_basis_root_coordinates':Z,'pureD_mode_basis_D_coordinates':K,'failure':failure,'scope':'Fixed104-output source effects; all first-X outputs may gain arbitrary rows of the5-dimensional pureD part of eventual8 mixed observations. Success would still require compatible route choices, literal histories, all forward compensation, endpoint decoder and full invoice.'}
    if failure:
        row={};b=F(0)
        for ix,c in failure['combination'].items():row=e.plus(row,equations[ix]['coeff'],c);b+=c*equations[ix]['rhs']
        assert not row and b==failure['rhs']!=0;result['inconsistency_certificate_verified']=True;result['certificate_equations']={i:equations[i] for i in failure['combination']}
    else:
        solution={}
        for p in sorted(echelon,reverse=True):v,b,pr=echelon[p];solution[p]=b-sum(c*solution.get(i,F(0)) for i,c in v.items() if i!=p)
        assert all(sum(c*solution.get(i,F(0)) for i,c in eq['coeff'].items())==eq['rhs'] for eq in equations);result['solution']=solution
    a.output.write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','variables','equations_processed','rank']},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
