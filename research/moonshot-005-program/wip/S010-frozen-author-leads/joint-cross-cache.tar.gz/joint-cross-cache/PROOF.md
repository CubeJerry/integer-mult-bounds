# Joint pure-D cache transfer and observable quotient

Author exact finite evidence, independent review pending. This is a bounded source test, not a global impossibility theorem or a new kappa.

The original standalone parent Q is pinned at a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc. Its independent hosted-dual body supplies271 genuinely pure-D history rows; all are singleton original-D rows. No D projection of a B-contaminated history is admitted.

Reverse automatic differentiation of the complete original primal body tracks the future104 first-X outputs of EVERY raw and owned recipient at every actual chart. It includes injections into an encoded role other than the desired output, and into cohort auxiliaries. The boundary derivative is explicitly verified to be identity on the104 original first-X roles and zero on every other role. Granting all stationary history copies gives529 chart/effect pairs and14479 scalar injection columns.

A larger overapproximation also grants every intermediate pure-D-history chart nested inside any existing raw or owned MOVE. It grants incompatible alternatives for the same MOVE simultaneously. This increases to733 chart/effect pairs and14807 injection columns. Failure in this overapproximation is therefore sufficient for the narrower fixed-route test.

For desired N=E_S G_SH/2 with S=(17,19,38,40),53 original-D coordinate blocks fail in both tests. Each failed block has a rational dual witness that annihilates EVERY available future-X effect and evaluates nonzero on the requested target. The scripts check all those dot products exactly. Thus no joint mixing of the granted singleton-history injections supplies this exact N while leaving the other first-X outputs unchanged.

## Granting observable changes to all other X outputs

Let B=(5,56,65,69,77,96,100,103), W=G_SB (rank3), and choose the5-dimensional kernel basis of W. Its corresponding D functionals K=ker(W)*G_BH are exactly the pure-D part of eventual8 mixed observations r=G_BH*d+2G_BS*c. They remain pure-D for every physical c because ker(W)*G_BS=0.

The second exact test grants an arbitrary row of K to EVERY one of104 first-X outputs. It asks whether N+O*K lies in the entire refined source space, with104*5=520 rational unknowns. It is inconsistent:521 processed equations, coefficient rank498, with an explicit six-equation certificate0=1/2. The certificate is re-summed and checked, rather than inferred from a floating rank. The six equations arise from D ports0,1,2,4,5,7 at one quotient-X component38.

This broader grant avoids demanding unnecessary unchanged X outputs when a real later mixed-observation decoder could remove a pure-D response. It remains a test of this fixed requested N class and fixed original pure-D histories/source choreography. Mixed B/D histories with an honest current-Hub quotient, singular packet/raw-source exchanges, a redesigned D-only code, new moving observations, and a changed global fitting matrix remain outside scope. No complete forward-row or invoice completion is supplied.
