#!/usr/bin/env python3
"""Joint exact future-X transfer of all pureD stationary native histories."""
import argparse,copy,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def sha(b):return hashlib.sha256(b).hexdigest()
def main(a):
    ep=HERE/'extract_rail.py';assert sha(ep.read_bytes())=='7eba542316bfb1a0ae70fee8f2201b7b15abfcfa3cb59f84014f3331608ec372';sp=importlib.util.spec_from_file_location('joint_cache_engine',ep);e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e)
    qb=(HERE.parent/'two-lane/source-evidence/rail-consumer.json.gz').read_bytes();assert sha(qb)=='a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc';q=json.loads(gzip.decompress(qb));s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);roles={int(k):v for k,v in q['source_role_map'].items()};host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);D={roles[y] for x,y in host.values()};dual_public={roles[r] for pair in host.values() for r in pair};uf=list(range(400));current={i:i for i in range(400)};nodes=[]
    def find(x):
        while uf[x]!=x:uf[x]=uf[uf[x]];x=uf[x]
        return x
    def union(x,y):
        x,y=find(x),find(y)
        if x!=y:uf[y]=x
    for op in q['program']:
        typ,r=op[:2]
        if typ=='INIT':n=len(uf);uf.append(n);current[r]=n
        node=current[r];nodes.append(node)
        if typ in ['ADD','COPY']:union(node,current[op[2]])
        if typ=='CLEAR':del current[r]
    colors={}
    for i in range(400):colors.setdefault(find(i),set()).add('D' if i in dual_public else 'P')
    assert all(len(v)==1 for v in colors.values());color=lambda n:next(iter(colors.get(find(n),{'P'})))
    primal=[(i,o) for i,o in enumerate(q['program']) if i>=40 and color(nodes[i])=='P'];dual=[(i,o) for i,o in enumerate(q['program']) if color(nodes[i])=='D'];spaces=list(map(e.span,q['frames']));basis={i:{i:F(1)} for i in range(400)}
    rows=copy.deepcopy(basis);loc=dict(enumerate(q['initial']));history={};seen=set()
    def record(t,r):
        row=rows[r]
        if not row or not set(row)<=D:return
        key=(loc[r],tuple(sorted(row.items())))
        if key in seen:return
        seen.add(key);history.setdefault(loc[r],[]).append({'old_event':t,'field':r,'row':dict(row)})
    for r in range(400):record(-1,r)
    for t,o in dual:
        typ,r=o[:2]
        if typ=='INIT':loc[r]=o[2];rows[r]={}
        elif typ=='CLEAR':del loc[r];del rows[r];continue
        elif typ=='MOVE':assert loc[r]==o[2];loc[r]=o[3]
        elif typ in ['ADD','COPY']:assert loc[r]==loc[o[2]]==o[4];rows[r]=e.plus(rows[r],rows[o[2]],F(o[3]))
        elif typ=='SCALE':rows[r]={k:F(o[2])*v for k,v in rows[r].items()}
        record(t,r)
    # Reverse automatic differentiation includes every raw and OWNED primal
    # recipient. This permits injections through a different encoded X role.
    pp=q['program'][:40]+[o for t,o in primal];pr,at,pb=e.run(pp,q['initial'],400,q['owned_fields'],spaces,basis);adj={roles[j]:{j:F(1)} for j in s['live']};candidates={}
    def save(t):
        for r,v in adj.items():
            if not v or r not in at or at[r] not in history:continue
            key=(at[r],tuple(sorted(v.items())))
            candidates.setdefault(key,{'after_old_event':t,'recipient':r,'chart':at[r],'future_X_effect':dict(v)})
    refinement_count=0
    for t,o in reversed(primal):
        save(t);typ,r=o[:2]
        if a.refine and typ=='MOVE' and adj.get(r):
            A,B=spaces[o[2]],spaces[o[3]];lo,hi=(A,B) if A<B else (B,A)
            for chart in history:
                if not lo<spaces[chart]<hi:continue
                key=(chart,tuple(sorted(adj[r].items())))
                if key not in candidates:
                    candidates[key]={'split_old_MOVE':t,'recipient':r,'chart':chart,'future_X_effect':dict(adj[r]),'old_MOVE':o};refinement_count+=1
        if typ=='CLEAR':at[r]=o[2];adj[r]={}
        elif typ=='INIT':del at[r];adj.pop(r,None)
        elif typ=='MOVE':assert at[r]==o[3];at[r]=o[2]
        elif typ in ['ADD','COPY']:
            if adj.get(r):adj[o[2]]=e.plus(adj.get(o[2],{}),adj[r],F(o[3]))
        elif typ=='SCALE':adj[r]={j:F(o[2])*c for j,c in adj.get(r,{}).items()}
    save(39)
    # Every final-X derivative after the body is the identity on the initial
    # raw first-X state. No Y or owned derivative survives at that boundary.
    assert {r:v for r,v in adj.items() if v}=={roles[j]:{j:F(1)} for j in s['live']}
    sys.path.insert(0,str(a.repo/'research/moonshot-005-program/results/joint-current-row-codes/review-star'));from engine import root9,rank
    roots={j:root9(s['frames'][s['initial'][j]][0]) for j in s['live']};G=lambda i,j:sum(x*y for x,y in zip(roots[i],roots[j]))/2;S=[17,19,38,40];singleton={h:[] for h in H};multi=[];decl=[]
    for c in candidates.values():
        for h in history[c['chart']]:
            ix=len(decl);item={'id':ix,'injection':c,'donor_history':h};decl.append(item)
            if len(h['row'])==1:
                d,coef=next(iter(h['row'].items()));port=next(hh for hh in H if roles[host[hh][1]]==d);singleton[port].append((ix,{j:v*coef for j,v in c['future_X_effect'].items()}))
            else:multi.append(item)
    tests={};failed=[]
    for h in H:
        target={j:G(j,h)/2 for j in S if G(j,h)};expr,left=e.coordinate_expression(target,singleton[h]);rk=rank([[row.get(j,F(0)) for j in s['live']] for ix,row in singleton[h]])
        test={'target':target,'contact_vectors':len(singleton[h]),'contact_rank':rk,'fits':not left,'expression':expr,'remainder':left}
        if left:
            echelon={}
            for ix,vector in singleton[h]:
                row=dict(vector)
                while row:
                    p=min(row);v=row[p]
                    if p not in echelon:echelon[p]={j:c/v for j,c in row.items()};break
                    row=e.plus(row,echelon[p],-v)
            k=min(left);dual={k:F(1)}
            for p in sorted(echelon,reverse=True):
                c=sum(v*dual.get(j,F(0)) for j,v in echelon[p].items());dual=e.plus(dual,{p:F(1)},-c)
            dot=lambda row:sum(v*dual.get(j,F(0)) for j,v in row.items())
            assert all(dot(v)==0 for ix,v in singleton[h]) and dot(target)==left[k]!=0
            test['dual_witness']=dual;test['dual_target_value']=dot(target)
        tests[h]=test
        if left:failed.append(h)
    result={'status':'JOINT_FUTURE_X_PURED_CACHE_PROBE','parent_sha256':sha(qb),'all_raw_and_owned_X_recipient_effects_included':True,'pure_D_histories':sum(map(len,history.values())),'distinct_chart_effect_pairs':len(candidates),'monotone_refinement_effect_pairs':refinement_count,'injection_columns':len(decl),'multi_D_history_injection_columns':len(multi),'singleton_block_tests':tests,'failed_singleton_D_ports':failed,'scope':'Exact full-X transfer with original pure-D histories, granting arbitrary stationary caches; singleton tests do not exclude multicoordinate-D history combinations until checked. Refined mode grants incompatible same-MOVE alternatives simultaneously, so success is only a route-choice lead. No forward-row or invoice completion.'}
    if multi:
        vectors=[]
        for item in decl:
            row={}
            for j,v in item['injection']['future_X_effect'].items():
                for d,c in item['donor_history']['row'].items():row[(j,d)]=v*c
            vectors.append((item['id'],row))
        target={(j,roles[host[h][1]]):G(j,h)/2 for j in S for h in H if G(j,h)};expr,left=e.coordinate_expression(target,vectors);result['joint_full_matrix_fit']=not left;result['joint_full_matrix_expression']=expr;result['joint_full_matrix_remainder']=[{'X':j,'D':d,'coefficient':c} for (j,d),c in left.items()]
    else:result['joint_full_matrix_fit']=not failed
    result['injection_manifest']=decl;a.output.write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','pure_D_histories','distinct_chart_effect_pairs','injection_columns','multi_D_history_injection_columns','failed_singleton_D_ports','joint_full_matrix_fit']},indent=2))
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--refine',action='store_true');main(p.parse_args())
