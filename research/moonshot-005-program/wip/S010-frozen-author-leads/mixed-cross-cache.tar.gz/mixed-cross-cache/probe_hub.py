#!/usr/bin/env python3
"""Actual mixed dual history quotient by exact final current Hub B rows."""
import argparse,copy,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def main(a):
    sp=importlib.util.spec_from_file_location('mixed_cache_engine',HERE/'extract_rail.py');e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e);qb=(HERE.parent/'two-lane/source-evidence/rail-consumer.json.gz').read_bytes();assert hashlib.sha256(qb).hexdigest()=='a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc';q=json.loads(gzip.decompress(qb));s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);roles={int(k):v for k,v in q['source_role_map'].items()};host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);D={roles[y] for x,y in host.values()};Bs={roles[x] for x,y in host.values()};dual_public=Bs|D;uf=list(range(400));current={i:i for i in range(400)};nodes=[]
    def find(x):
        while uf[x]!=x:uf[x]=uf[uf[x]];x=uf[x]
        return x
    def union(x,y):
        x,y=find(x),find(y)
        if x!=y:uf[y]=x
    for o in q['program']:
        typ,r=o[:2]
        if typ=='INIT':n=len(uf);uf.append(n);current[r]=n
        node=current[r];nodes.append(node)
        if typ in ['ADD','COPY']:union(node,current[o[2]])
        if typ=='CLEAR':del current[r]
    colors={}
    for i in range(400):colors.setdefault(find(i),set()).add('D' if i in dual_public else 'P')
    assert all(len(v)==1 for v in colors.values());color=lambda n:next(iter(colors.get(find(n),{'P'})));dual=[(i,o) for i,o in enumerate(q['program']) if color(nodes[i])=='D'];rows={i:{i:F(1)} for i in range(400)};loc=dict(enumerate(q['initial']));history=[];seen=set()
    def save(t,r):
        row=rows[r]
        if not row or not set(row)<=dual_public:return
        key=(loc[r],tuple(sorted(row.items())))
        if key in seen:return
        seen.add(key);history.append({'old_event':t,'role':r,'chart':loc[r],'raw':dict(row)})
    for r in dual_public:save(-1,r)
    for t,o in dual:
        typ,r=o[:2]
        if typ=='INIT':loc[r]=o[2];rows[r]={}
        elif typ=='CLEAR':del loc[r];del rows[r];continue
        elif typ=='MOVE':assert loc[r]==o[2];loc[r]=o[3]
        elif typ in ['ADD','COPY']:assert loc[r]==loc[o[2]]==o[4];rows[r]=e.plus(rows[r],rows[o[2]],F(o[3]))
        elif typ=='SCALE':rows[r]={k:F(o[2])*v for k,v in rows[r].items()}
        save(t,r)
    for b in Bs:assert loc[b]==127 and rows[b].get(b)==1 and not (set(rows[b])&Bs)-{b}
    for item in history:
        item['B_nuisance']={b:c for b,c in item['raw'].items() if b in Bs};effective=dict(item['raw'])
        for b,c in item['B_nuisance'].items():effective=e.plus(effective,rows[b],-c)
        assert set(effective)<=D;item['effective_D']=effective
    sys.path.insert(0,str(a.repo/'research/moonshot-005-program/results/joint-current-row-codes/review-star'));from engine import root9,rank
    roots={i:root9(s['frames'][s['initial'][i]][0]) for i in s['live']};G=lambda i,j:sum(x*y for x,y in zip(roots[i],roots[j]))/2;atHub=[(k,x['effective_D']) for k,x in enumerate(history) if x['chart']==127 and x['effective_D']];rk=rank([[r.get(d,F(0)) for d in sorted(D)] for k,r in atHub]);tests={}
    for i in [17,19,38,40]:
        target={roles[host[h][1]]:G(i,h)/2 for h in H if G(i,h)};expr,left=e.coordinate_expression(target,atHub);tests[i]={'fits':not left,'expression':expr,'remainder':left}
    result={'status':'EXACT_MIXED_HISTORY_HUB_QUOTIENT_PROBE','parent_sha256':hashlib.sha256(qb).hexdigest(),'dual_operations':len(dual),'mixed_histories':len(history),'nonzero_Hub_effective_observations':len(atHub),'Hub_effective_D_rank':rk,'tests':tests,'history':history,'scope':'Effective rows use actual final z=b+R*d, never an assumed Gram baseline. Histories are granted as genuine chart copies; source word, lifetime invoice and any effect on forward Y chronology remain unconstructed.'};a.output.write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['status','mixed_histories','nonzero_Hub_effective_observations','Hub_effective_D_rank']},indent=2));print({i:x['fits'] for i,x in tests.items()})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
