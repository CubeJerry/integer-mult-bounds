#!/usr/bin/env python3
"""Facet-local mixed histories at the actual pre-consumer cyclic endpoint."""
import argparse,copy,gzip,hashlib,importlib.util,json,sys
from fractions import Fraction as F
from pathlib import Path
HERE=Path(__file__).resolve().parent
def kernel(A,n=None):
    n=n if n is not None else len(A[0]);R=[list(r) for r in A];piv=[];t=0
    for c in range(n):
        z=next((i for i in range(t,len(R)) if R[i][c]),None)
        if z is None:continue
        R[t],R[z]=R[z],R[t];v=R[t][c];R[t]=[x/v for x in R[t]]
        for i in range(len(R)):
            if i!=t:
                v=R[i][c];R[i]=[x-v*y for x,y in zip(R[i],R[t])]
        piv.append(c);t+=1
    ans=[]
    for free in range(n):
        if free in piv:continue
        v=[F(0)]*n;v[free]=F(1)
        for i,c in enumerate(piv):v[c]=-R[i][free]
        ans.append(v)
    return ans
def main(a):
    sp=importlib.util.spec_from_file_location('funded_spaces_engine',HERE/'extract_rail.py');e=importlib.util.module_from_spec(sp);sp.loader.exec_module(e);qb=(HERE.parent/'two-lane/source-evidence/rail-consumer.json.gz').read_bytes();assert hashlib.sha256(qb).hexdigest()=='a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc';q=json.loads(gzip.decompress(qb));s=e.load(a.repo/'research/shared-wire-split-composition/data/final.json.gz',e.SOURCE_PIN);roles={int(k):v for k,v in q['source_role_map'].items()};host={s['live'][k]:(x,y) for k,x,y in zip(s['hosted']['Dports'],s['hosted']['X2'],s['hosted']['Y2'])};H=list(host);D={roles[y] for x,y in host.values()};Bs={roles[x] for x,y in host.values()};dual_public=Bs|D;uf=list(range(400));current={i:i for i in range(400)};nodes=[]
    def find(x):
        while uf[x]!=x:uf[x]=uf[uf[x]];x=uf[x]
        return x
    def union(x,y):
        x,y=find(x),find(y)
        if x!=y:uf[y]=x
    for o in q['program']:
        typ,r=o[:2]
        if typ=='INIT':n=len(uf);uf.append(n);current[r]=n
        node=current[r];nodes.append(node)
        if typ in ['ADD','COPY']:union(node,current[o[2]])
        if typ=='CLEAR':del current[r]
    colors={}
    for i in range(400):colors.setdefault(find(i),set()).add('D' if i in dual_public else 'P')
    assert all(len(v)==1 for v in colors.values());color=lambda n:next(iter(colors.get(find(n),{'P'})));stop=q['consumer']['begin'];primal=[(i,o) for i,o in enumerate(q['program'][:stop]) if color(nodes[i])=='P'];dual=[(i,o) for i,o in enumerate(q['program'][:stop]) if color(nodes[i])=='D'];rows={i:{i:F(1)} for i in range(400)};loc=dict(enumerate(q['initial']));history=[];seen=set()
    def save(t,r):
        row=rows[r]
        if not row or not set(row)<=dual_public:return
        key=(loc[r],tuple(sorted(row.items())))
        if key in seen:return
        seen.add(key);history.append({'old_event':t,'role':r,'chart':loc[r],'raw':dict(row)})
    for r in dual_public:save(-1,r)
    for t,o in dual:
        typ,r=o[:2]
        if typ=='INIT':loc[r]=o[2];rows[r]={}
        elif typ=='CLEAR':del loc[r];del rows[r];continue
        elif typ=='MOVE':assert loc[r]==o[2];loc[r]=o[3]
        elif typ in ['ADD','COPY']:assert loc[r]==loc[o[2]]==o[4];rows[r]=e.plus(rows[r],rows[o[2]],F(o[3]))
        elif typ=='SCALE':rows[r]={k:F(o[2])*v for k,v in rows[r].items()}
        save(t,r)
    for b in Bs:assert loc[b]==127 and rows[b].get(b)==1 and not (set(rows[b])&Bs)-{b}
    for k,item in enumerate(history):
        item['id']=k;item['B_nuisance']={b:c for b,c in item['raw'].items() if b in Bs};effective=dict(item['raw'])
        for b,c in item['B_nuisance'].items():effective=e.plus(effective,rows[b],-c)
        assert set(effective)<=D;item['effective_D']={h:effective.get(roles[host[h][1]],F(0)) for h in H if effective.get(roles[host[h][1]],F(0))}
    M=[]
    for h in H:
        x,y=host[h];M.append([rows[roles[x]].get(roles[host[j][1]],F(0))+F(h==j) for j in H])
    Z=kernel(M);assert len(Z)==14
    facets={}
    for h in H:
        facet=s['final'][host[h][1]];candidates=[x for x in history if x['chart']==facet and x['effective_D']];picked=[];ec={}
        assert all(set(item['effective_D'])<={h} for item in candidates),'effective facet locality on the COMPLETE actual row'
        assert any(item['effective_D']=={h:F(1)} for item in candidates),'genuine original D_j is present at its facet'
        for item in candidates:
            row=dict(item['effective_D'])
            while row:
                p=min(row);v=row[p]
                if p not in ec:ec[p]={j:c/v for j,c in row.items()};picked.append(item);break
                row=e.plus(row,ec[p],-v)
        constraints=[[sum(item['effective_D'].get(j,F(0))*z[t] for t,j in enumerate(H)) for item in picked] for z in Z];null=kernel(constraints,len(picked));modes=[]
        for coeff in null:
            row={};raw={};P={};terms=[]
            for c,item in zip(coeff,picked):
                if not c:continue
                row=e.plus(row,item['effective_D'],c);raw=e.plus(raw,item['raw'],c);P=e.plus(P,item['B_nuisance'],c);terms.append({'history_id':item['id'],'coefficient':c})
            assert row and all(sum(row.get(j,F(0))*z[t] for t,j in enumerate(H))==0 for z in Z);modes.append({'effective_D':row,'raw':raw,'B_nuisance':P,'terms':terms})
        facets[h]={'facet':facet,'history_rows':len(candidates),'observation_space_dimension':len(picked),'useful_intersection_dimension':len(modes),'observation_basis_history_ids':[x['id'] for x in picked],'useful_modes':modes}
    # Greedy independent representatives are a lower bound; no maximality
    # claim unless a separate subspace-transversal algorithm verifies it.
    selected=[];ec={}
    J=q['consumer']['selected_return_ports'];order=J+[h for h in H if h not in J]
    for h in order:
        for mi,mode in enumerate(facets[h]['useful_modes']):
            row=dict(mode['effective_D'])
            while row:
                p=min(row);v=row[p]
                if p not in ec:ec[p]={j:c/v for j,c in row.items()};selected.append({'port':h,'mode':mi});break
                row=e.plus(row,ec[p],-v)
            if row:break
    assert all(v['observation_space_dimension']==1 and v['useful_intersection_dimension']==0 for v in facets.values())
    full,fl,fb=e.run(q['program'],q['initial'],400,q['owned_fields'],list(map(e.span,q['frames'])),{i:{i:F(1)} for i in range(400)})
    wrong=[]
    for h in H:
        facet=facets[h]['facet']
        for item in history:
            if item['chart']!=facet:continue
            effective=dict(item['raw'])
            for b,c in item['B_nuisance'].items():effective=e.plus(effective,full[b],-c)
            if set(effective)-{roles[host[h][1]]}:wrong.append({'facet_port':h,'history_id':item['id']});break
    assert wrong,'post-consumer Hub substitution must be detected, not silently admitted'
    result={'status':'EXACT_FACET_MIXED_OBSERVATION_SPACES','parent_sha256':hashlib.sha256(qb).hexdigest(),'preconsumer_stop':stop,'primal_operations':len(primal),'dual_operations':len(dual),'M':M,'H':H,'kernel':Z,'history':history,'facets':facets,'original_J31':J,'greedy_independent_representatives':selected,'all96_facet_effective_spaces_exactly_original_D_coordinate':True,'all96_facet_intersections_with_rowM82_zero':True,'wrong_postconsumer_Hub_fingerprint_rejected':wrong,'scope':'Exact fixed-source fingerprint. Every facet-local mixed history quotient is only a scalar d_j; arbitrary unchanged facet returns therefore remain coordinate observations even with joint decoding. Lower-chart acquisition, moving caches, altered code and feedback remain outside scope.'};a.output.write_text(json.dumps(e.clean(result),sort_keys=True,indent=2)+'\n');print('useful facet counts',sum(bool(v['useful_modes']) for v in facets.values()),'greedy independent',len(selected),'selectedJ',sum(x['port'] in J for x in selected));print('J31 dimensions',{h:facets[h]['useful_intersection_dimension'] for h in J})
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--output',type=Path,required=True);main(p.parse_args())
