# Actual effective facet locality of the cyclic source

Author exact finite source fingerprint, independent review pending. Both strict suppliers and all five foundations remain open; no new kappa.

The pinned parent is standalone400-input Q a235a7e58f9eb96c6d409a88095fd6b59c977977baabb8735c76b2b820dcbedc. Stop at its actual pre-consumer boundary4779. The true current Hub rows are z0=b+R0*d, with M0=I+R0 of rank82 and14-dimensional kernel. The31 coordinate-return consumer has NOT run. The script records complete rational rows for every raw and owned history of the genuine hosted-dual source.

For every one of96 terminal facets F_j and every history row r at F_j, let P be its coefficient on the96 ORIGINAL independent B inputs. The exact current-Hub cancellation is

    r-P*z0 = lambda_r*d_j.

This identity is checked on the entire400-coordinate row. Every facet has the genuine original d_j history as well, so its effective observation space is EXACTLY span(d_j). All96 spaces have zero intersection with row(M0); individual coordinate fields become useful only through joint observation spaces, as in the admitted B7+24 construction.

Therefore replacing any of the existing31 facet-toHub packets by an arbitrary linear combination of actual facet-local mixed histories cannot alter its effective observation beyond rescaling d_j. This statement already permits arbitrary caching, mixtures of histories from different clocks at that same facet, arbitrary joint mixing of the returned fields, and an honest Hub decoder. It does not claim the coordinate choice certificate anew; it says this proposed local payload enlargement adds no new subspace to that coordinate problem.

The negative control recomputes the fingerprint with the WRONG post-consumer Hub z58 instead of z0. That produces foreign-coordinate apparent observations and is rejected. The distinction between these two actual endpoints is essential: the later coordinate updates are not a free side-information premise at acquisition time.

An earlier separate Hub-history quotient confirms only rank31 effective pure-D information atHub after the31 consumer; it does not grant full Gram. Lower-chart return birth, moving caches between incomparable facets, altered original raw words, packet/source mode exchange and additional current-row feedback are outside this fingerprint.
